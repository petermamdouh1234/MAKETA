import React from "react";
import { Link } from "react-router-dom";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "../../components/ui/navigation-menu";
import { useScrollReveal } from "../../hooks/useScrollReveal";

export const FrameScreen = () => {
  useScrollReveal();
  
  const navigationItems = [
    { label: "HOME", href: "/", isActive: true },
    { label: "OUR WORK", href: "/our-work", isActive: false },
    { label: "ABOUT US", href: "/about-us", isActive: false },
    { label: "SERVICES", href: "/our-services-u45-main", isActive: false },
    { label: "CONTACT US", href: "/contact-us", isActive: false },
  ];

  const featureItems = [
    { text: "Strategies that amplify your voice" },
    { text: "Creative visuals that get noticed" },
    { text: "Digital + Offline presence" },
    { text: "Growing brands into leaders" },
  ];

  const aboutUsLinks = [
    { label: "Story", href: "/about-us#our-story" },
    { label: "Our Clients", href: "/about-us#our-clients" },
    { label: "Team", href: "/about-us#our-team" },
  ];

  const servicesLinks = [
    { label: "Marketing", href: "/our-services-u45-marketing" },
    { label: "Branding & Design", href: "/our-services-u45-branding" },
    { label: "Media Production", href: "/our-services-u45-media-production" },
    { label: "Web & App Development", href: "/our-services-u45-web-u38-app" },
  ];

  const socialMediaLinks = [
    { icon: "https://c.animaapp.com/mg7bpj7aUsX0qj/img/social-media-icon-square-facebook.svg", label: "Facebook", href: "#" },
    { icon: "https://c.animaapp.com/mg7bpj7aUsX0qj/img/social-media-icon-square-instagram.svg", label: "Instagram", href: "#" },
    { icon: "https://c.animaapp.com/mg7bpj7aUsX0qj/img/social-media-icon-square-linkedin.svg", label: "LinkedIn", href: "#" },
  ];

  return (
    <div className="bg-black min-h-screen w-full relative overflow-hidden">
      {/* Header */}
      <header
        className="flex items-center justify-between w-full px-4 md:px-8 py-4 md:py-6 relative min-h-[80px] md:min-h-[120px] reveal-fade"
      >
        <div className="reveal-left">
          <Link to="/">
            <img
              className="w-[80px] h-[80px] md:w-[100px] md:h-[100px] lg:w-[120px] lg:h-[120px] object-cover hover:scale-105 transition-transform duration-300"
              alt="Maketa Agency Logo"
              src="https://c.animaapp.com/mg7bpj7aUsX0qj/img/logo-copy-1-8.png"
            />
          </Link>
        </div>

        <NavigationMenu className="reveal-right hidden md:block">
          <NavigationMenuList className="flex items-center gap-4 lg:gap-[60px]">
            {navigationItems.map((item) => (
              <NavigationMenuItem key={item.label}>
                <NavigationMenuLink asChild>
                  <Link
                    className={`relative w-fit [font-family:'Gilroy-Bold-Bold',Helvetica] font-bold text-xs lg:text-sm tracking-[0] leading-[normal] transition-all duration-300 hover:text-[#ffcc04] hover:scale-105 ${
                      item.isActive ? "text-[#ffcc04]" : "text-white"
                    }`}
                    to={item.href}
                  >
                    {item.label}
                  </Link>
                </NavigationMenuLink>
              </NavigationMenuItem>
            ))}
          </NavigationMenuList>
        </NavigationMenu>
      </header>

      {/* Hero Section */}
      <main className="relative min-h-[calc(100vh-80px)] md:min-h-[calc(100vh-120px)] px-4 md:px-8 py-8 md:py-16 flex items-center justify-center text-center">
        {/* Metallic Shape */}
        <img
          className="absolute left-[5%] md:left-[10%] top-[20%] w-[300px] md:w-[450px] lg:w-[600px] h-[225px] md:h-[337px] lg:h-[450px] object-contain opacity-80 animate-pulse-slow"
          alt="Metallic Shape"
          src="https://c.animaapp.com/mg7bpj7aUsX0qj/img/layer-1-1-1.png"
        />

        {/* Social Media Icons (Left Side) - Hidden on mobile */}
        <div className="hidden md:flex absolute left-4 lg:left-8 top-1/2 transform -translate-y-1/2 flex-col items-center gap-4 reveal-left">
          <span className="[font-family:'Gilroy-Medium-Medium',Helvetica] font-medium text-white text-xs tracking-[0] leading-[normal] rotate-90 whitespace-nowrap">
            Follow us
          </span>
          {socialMediaLinks.map((social, index) => (
            <Link key={index} to={social.href} className="group">
              <img
                className="w-[20px] h-[20px] transition-transform group-hover:scale-110"
                alt={`${social.label} icon`}
                src={social.icon}
              />
            </Link>
          ))}
        </div>

        {/* Main Heading */}
        <div className="relative z-10 max-w-6xl mx-auto px-4">
          <h1 className="[font-family:'Bebas_Neue',Helvetica] font-normal text-white text-responsive-hero tracking-[0] leading-[0.8] mb-4 md:mb-8 reveal-scale">
            <span className="block">DECLARE</span>
            <span className="block text-[#ffcc04] [font-family:'Rockybilly-Regular',Helvetica] italic transform rotate-[-5deg] inline-block ml-2 md:ml-8">Presence</span>
            <span className="block">YOUR</span>
          </h1>

          {/* Description */}
          <p className="[font-family:'Gilroy-SemiBold-SemiBold',Helvetica] font-semibold text-white text-responsive-small tracking-[0] leading-6 md:leading-8 max-w-3xl mx-auto reveal-up">
            WE ARE A FULL-SERVICE EGYPT MARKETING AGENCY, CREATING HIGH IMPACT EXPERIENCES FOR BRANDS.
            FROM STRATEGY AND DESIGN TO DIGITAL AND OFFLINE CAMPAIGNS, WE HELP BUSINESSES DECLARE THEIR PRESENCE, CONNECT WITH THEIR AUDIENCE, AND GROW WITH CONFIDENCE.
          </p>
        </div>
      </main>

      {/* Why Maketa Section */}
      <section className="px-4 md:px-8 py-8 md:py-16 text-center">
        <h2 className="[font-family:'Bebas_Neue',Helvetica] font-normal text-white text-responsive-title tracking-[0] leading-[normal] mb-6 md:mb-12 reveal-up">
          WHY <Link to="/" className="text-[#ffcc04] hover:text-[#ffdd44] transition-colors">MAKETA</Link>
        </h2>

        <div className="flex flex-wrap justify-center gap-4 md:gap-8 max-w-6xl mx-auto">
          {featureItems.map((item, index) => (
            <div key={index} className="flex items-center gap-2 md:gap-4 bg-transparent border-2 border-[#ffcc04] text-[#ffcc04] px-4 md:px-6 py-2 md:py-3 rounded-[15px] reveal-stagger hover:bg-[#ffcc04] hover:text-black transition-colors duration-300">
              <span className="[font-family:'Gilroy-SemiBold-SemiBold',Helvetica] font-semibold text-sm md:text-base tracking-[0] leading-[normal]">
                {item.text}
              </span>
              <img
                className="w-[16px] h-[16px] md:w-[20px] md:h-[20px]"
                alt="Star icon"
                src="https://c.animaapp.com/mg7bpj7aUsX0qj/img/star-1.svg"
              />
            </div>
          ))}
        </div>
      </section>

      {/* Detailed Description Section */}
      <section className="px-4 md:px-8 py-8 md:py-16">
        <p className="[font-family:'Gilroy-Medium-Medium',Helvetica] font-medium text-white text-responsive-small tracking-[0] leading-6 md:leading-8 max-w-5xl mx-auto reveal-fade">
          Every brand has a story. But in a crowded market, stories can get lost. That's where we step in.
          At Maketa, we believe presence is more than just being seen—it's about being remembered, respected, and chosen. We combine strategic thinking, creative design, and bold marketing to transform brands into experiences that audiences connect with on every level. 
          From launching startups that want to make their first impression, to helping established companies reinvent their identity, we craft tailored solutions that declare your presence with impact. Our approach blends digital innovation with offline activations, ensuring your brand lives wherever your audience does—online, in print, at events, and beyond.
          <br /><br />
          With Maketa, you don't just run campaigns—you build movements that inspire loyalty, spark conversations, and drive growth.
        </p>
      </section>

      {/* Discover Who We Are Section */}
      <section className="relative px-8 py-16 text-center flex flex-col items-center justify-center">
        {/* Background decorative image */}
        <img
          className="absolute right-0 bottom-0 w-[600px] h-[450px] object-contain opacity-50 reveal-right animate-pulse-slow"
          alt="Metallic Shape"
          src="https://c.animaapp.com/mg7bpj7aUsX0qj/img/layer-1-1-1.png"
        />
        <Link to="/about-us" className="inline-block reveal-scale relative z-10">
          <h2 className="[font-family:'Bebas_Neue',Helvetica] font-normal text-white text-[80px] md:text-[100px] tracking-[0] leading-[normal] relative inline-block">
            DISCOVER 
            <span className="text-[#ffcc04] ml-4">WHO WE ARE</span>
            <span className="absolute bottom-0 left-0 w-full h-1 bg-white transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
          </h2>
        </Link>
      </section>

      {/* Footer */}
      <footer className="relative w-full bg-black py-16 mt-16">
        <div className="max-w-[1469px] mx-auto px-8">
          <div className="flex flex-col lg:flex-row gap-12 mb-12">
            {/* Logo */}
            <div className="reveal-left">
              <Link to="/"> {/* Ensure logo links to home */}
                <img
                  className="h-[191px] w-[191px] object-cover hover:scale-105 transition-transform duration-300"
                  alt="Logo"
                  src="https://c.animaapp.com/mg7bpj7aUsX0qj/img/logo-copy-1-8.png"
                />
              </Link>
            </div>

            {/* Footer Links Grid */}
            <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-[158px]">
              {/* About Us */}
              <div className="reveal-stagger">
                <h3 className="[font-family:'Gilroy-ExtraBold-ExtraBold',Helvetica] font-extrabold text-[#ffcc04] text-xl tracking-[0] leading-5 mb-[53px]">
                  About Us
                </h3>
                <div className="flex flex-col gap-[27.5px]">
                  {aboutUsLinks.map((link, index) => (
                    <Link
                      key={index}
                      to={link.href}
                      className="[font-family:'Gilroy-Medium-Medium',Helvetica] font-medium text-white text-lg tracking-[0] leading-[18px] hover:text-[#ffcc04] transition-colors"
                    >
                      {link.label}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Services */}
              <div className="reveal-stagger">
                <h3 className="[font-family:'Gilroy-ExtraBold-ExtraBold',Helvetica] font-extrabold text-[#ffcc04] text-xl tracking-[0] leading-5 mb-[53px]">
                  Services
                </h3>
                <div className="flex flex-col gap-[27.5px]">
                  {servicesLinks.map((link, index) => (
                    <Link
                      key={index}
                      to={link.href}
                      className="[font-family:'Gilroy-Medium-Medium',Helvetica] font-medium text-white text-lg tracking-[0] leading-[18px] hover:text-[#ffcc04] transition-colors"
                    >
                      {link.label === "Web & App Development" ? (
                        <>
                          Web &amp; App <br />
                          Development
                        </>
                      ) : (
                        link.label
                      )}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Contact Us */}
              <div className="reveal-stagger">
                <h3 className="[font-family:'Gilroy-ExtraBold-ExtraBold',Helvetica] font-extrabold text-[#ffcc04] text-xl tracking-[0] leading-5">
                  Contact Us
                </h3>
              </div>

              {/* Follow Us */}
              <div className="reveal-stagger">
                <h3 className="[font-family:'Gilroy-ExtraBold-ExtraBold',Helvetica] font-extrabold text-[#ffcc04] text-xl tracking-[0] leading-5 mb-[53px]">
                  Follow us
                </h3>
                <div className="flex flex-col gap-[15px]">
                  {socialMediaLinks.map((social, index) => (
                    <Link
                      key={index}
                      to={social.href}
                      className="flex items-center gap-[10px] group"
                    >
                      <img
                        className="w-[30px] h-[30px] transition-transform group-hover:scale-110"
                        alt={`${social.label} icon`}
                        src={social.icon}
                      />
                      <span className="[font-family:'Gilroy-Medium-Medium',Helvetica] font-medium text-white text-lg tracking-[0] leading-[18px] group-hover:text-[#ffcc04] transition-colors">
                        {social.label}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="reveal-fade">
            <p className="[font-family:'Gilroy-Medium-Medium',Helvetica] font-medium text-white text-lg tracking-[0] leading-[18px]">
              Copyright © 2025 | All Rights Reserved
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};
